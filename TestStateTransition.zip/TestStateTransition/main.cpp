﻿#include "mainwindow.h"
#include <QDebug>
#include <QApplication>
#include <QStateMachine>

class MyApplication : public QApplication {
public:
    MyApplication(int &argc, char **argv)
        : QApplication(argc, argv)
        , pStateMachine_(nullptr)
        , nFlag_(170)
    {
    }

    bool notify(QObject *receiver, QEvent *event) override
    {
        if (event->type() == QEvent::MouseButtonPress) {
            qint8 currentValue = receiver->property("myValue").toInt();
            qDebug() << "myValue:" << currentValue;
            if ((nFlag_ & (1 << currentValue)) != 0) {
                qDebug() << "bingo" << endl;
            }
        }
        return QApplication::notify(receiver, event);
    }
signals:
    void startWorking();
    void stopWorking();

private:
    QStateMachine *pStateMachine_;

    uint8_t nFlag_;
};

int main(int argc, char *argv[])
{
    MyApplication a(argc, argv);
    qDebug() << &a;
    MainWindow w;
    w.resize(700, 700);
    w.show();
    return a.exec();
}
