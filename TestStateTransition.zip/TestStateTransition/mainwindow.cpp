﻿#include "mainwindow.h"
#include "./ui_mainwindow.h"

bool isBitSet(uint8_t value, uint8_t position)
{
    // 检查位置是否有效
    if (position >= 8) {
        return false; // 或者可以抛出异常
    }

    // 使用位掩码检查特定位
    return (value & (1 << position)) != 0;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , p1(nullptr)
    , p2(nullptr)
    , p3(nullptr)
//, ui(new Ui::MainWindow)
{
    // ui->setupUi(this);
    p1 = new MyButton("01_pushbtn", this);
    p2 = new MyButton("02_pushbtn", this);
    p3 = new MyButton("03_pushbtn", this);

    p1->move(50, 50);
    p2->move(90, 50);
    p3->move(50, 90);

    p1->setNotice(1);
    p2->setNotice(2);
    p3->setNotice(4);
}

MainWindow::~MainWindow()
{
    // delete ui;
}
