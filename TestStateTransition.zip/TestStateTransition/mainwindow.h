﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QPainter>
#include <QMainWindow>
#include <QPushButton>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
} // namespace Ui
QT_END_NAMESPACE

bool isBitSet(uint8_t value, uint8_t position);

class MyButton : public QPushButton {
    Q_OBJECT
    Q_PROPERTY(qint8 myValue READ getMyValue WRITE setMyValue NOTIFY myValueChanged)
public:
    MyButton(const QString &text, QWidget *parent = nullptr)
        : QPushButton(text, parent){};

    virtual ~MyButton(){};

    void setNotice(qint8 value, bool bState = true)
    {
        bState_ = bState;
        setMyValue(value);
    };

    qint8 getMyValue() const { return m_myValue; }

    void setMyValue(qint8 value)
    {
        if (m_myValue != value) {
            m_myValue = value;
            emit myValueChanged(); // 发射属性变化信号
        }
    }

signals:
    void myValueChanged(); // 属性变化信号
protected:
    void paintEvent(QPaintEvent *e) override
    {
        QPainter painter(this);
        if (bState_ && m_myValue > -1) {
            if (isBitSet(170, m_myValue)) {
                painter.setBrush(Qt::red);
            }
        }
        painter.drawRect(rect());
        QPushButton::paintEvent(e);
        return;
    };

private:
    qint8 m_myValue; // 内部存储的 int8_t 值
private:
    bool bState_ = true;
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    // Ui::MainWindow *ui;

    MyButton *p1;
    MyButton *p2;
    MyButton *p3;
};
#endif // MAINWINDOW_H
